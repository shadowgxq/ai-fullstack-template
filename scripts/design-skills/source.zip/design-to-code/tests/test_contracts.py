"""Documentation/compatibility contracts, not a claim that generated apps work."""
from pathlib import Path
import re
import unittest

ROOT = Path(__file__).resolve().parents[2]
ALIASES = ['figma-to-code','figma-mcp-cache','figma-project-components','figma-visual-qa']


class Contracts(unittest.TestCase):
    def test_links_resolve(self):
        for folder in ['design-to-code','design-qa',*ALIASES]:
            for file in (ROOT/folder).rglob('*.md'):
                for link in re.findall(r'\]\(([^)]+)\)',file.read_text()):
                    if '://' in link or link.startswith('#'): continue
                    with self.subTest(file=str(file),link=link): self.assertTrue((file.parent/link.split('#')[0]).exists())

    def test_two_core_entries_are_small(self):
        for skill in ('design-to-code','design-qa'):
            content = (ROOT/skill/'SKILL.md').read_text()
            self.assertIn('name: '+skill,content); self.assertLess(len(content.splitlines()),85)

    def test_legacy_entries_are_thin_and_explicit(self):
        for skill in ALIASES:
            self.assertLess(len((ROOT/skill/'SKILL.md').read_text().splitlines()),25)
            self.assertIn('allow_implicit_invocation: false',(ROOT/skill/'agents/openai.yaml').read_text())
        self.assertIn('prepare-source',(ROOT/'figma-mcp-cache/SKILL.md').read_text())
        self.assertIn('禁止进入',(ROOT/'figma-mcp-cache/SKILL.md').read_text())
        self.assertIn('不改生产代码',(ROOT/'figma-project-components/SKILL.md').read_text())
        self.assertIn('只验证',(ROOT/'figma-visual-qa/SKILL.md').read_text())

    def test_native_not_dom_and_measurement_not_visual_pass(self):
        native = (ROOT/'design-to-code/references/targets/react-native.md').read_text()
        for phrase in ('WebView','DOM','not_run','平台'):
            self.assertIn(phrase,native)
        rules = (ROOT/'design-qa/references/comparison.md').read_text()
        self.assertIn('未测量不是豁免',rules)
        self.assertIn('不是自动视觉结论',rules)

    def test_no_source_tool_auto_execution(self):
        source = (ROOT/'design-to-code/references/sources/pencil.md').read_text()
        self.assertIn('只读',source); self.assertIn('不自动切换',source)
        self.assertIn('live_mcp=not_run',source)

    def test_no_duplicate_browser_implementations(self):
        for script in ('capture.mjs','inspect.mjs'):
            old = (ROOT/'figma-visual-qa/scripts'/script).read_text()
            self.assertIn('design-qa/scripts/web.mjs',old); self.assertLess(len(old.splitlines()),8)


if __name__ == '__main__': unittest.main()
